package com.info.reklamuygulama;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdCallback;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class OyunActivity extends AppCompatActivity {

    private TextView textViewSonuc;
    private Button buttonPuanKazan,buttonBolumGec;

    private int puan = 10 ;

    private AdView banner;

    private InterstitialAd interstitialAd;

    private RewardedAd rewardedAd;
    private RewardedAdLoadCallback yuklemeListener;
    private RewardedAdCallback calismaListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyun);

        buttonPuanKazan = findViewById(R.id.buttonPuanKazan);
        buttonBolumGec = findViewById(R.id.buttonBolumGec);
        textViewSonuc = findViewById(R.id.textViewSonuc);
        banner = findViewById(R.id.banner);

        //Başlangıçta izleme buttonu görünmez olacak.
        buttonPuanKazan.setVisibility(View.INVISIBLE);

        MobileAds.initialize(OyunActivity.this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        bannerKurulum();
        interstitialKurulum();
        rewardKurulum();

        buttonBolumGec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(puan >= 30 ){//Puan 30'a eşit veya büyükse bölüm geçebilir.

                    if(interstitialAd.isLoaded()){
                        interstitialAd.show();
                    }

                }else{
                    Toast.makeText(getApplicationContext()
                            ,"Sonraki bölüme geçmek için 30 puan gereklidir.",Toast.LENGTH_SHORT).show();
                    buttonPuanKazan.setVisibility(View.VISIBLE);
                }
            }
        });

        interstitialAd.setAdListener(new AdListener(){
            @Override
            public void onAdClosed() {//Çarpı işaretine veya geri tuşuna basıldığında çalışır.
                startActivity(new Intent(OyunActivity.this,SonrakiBolumActivity.class));
                finish();
            }
        });

        buttonPuanKazan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(rewardedAd.isLoaded()){
                    rewardedAd.show(OyunActivity.this,calismaListener);
                }

            }
        });

        calismaListener = new RewardedAdCallback() {

            @Override
            public void onUserEarnedReward(@NonNull RewardItem reward) {//Ödül Kazanıldığında
                puan = puan + 20 ;
                textViewSonuc.setText("Toplam Puan : "+puan);
                buttonPuanKazan.setVisibility(View.INVISIBLE);
            }

        };

    }

    public void bannerKurulum(){
        AdRequest adRequest = new AdRequest.Builder().build();
        banner.loadAd(adRequest);
    }

    public void interstitialKurulum(){
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
        interstitialAd.loadAd(new AdRequest.Builder().build());
    }

    public void rewardKurulum(){

        rewardedAd = new RewardedAd(this,"ca-app-pub-3940256099942544/5224354917");

        yuklemeListener = new RewardedAdLoadCallback() {
            @Override
            public void onRewardedAdLoaded() {//Başarılı Yüklendiğinde
                Log.e("yuklemeListener","onRewardedAdLoaded");
            }

            @Override
            public void onRewardedAdFailedToLoad(int errorCode) {//Yüklemede sorun olduğunda
                Log.e("yuklemeListener","onRewardedAdFailedToLoad");
            }
        };

        rewardedAd.loadAd(new AdRequest.Builder().build(), yuklemeListener);
    }
}