package com.info.satinalmaislemleri;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PurchasesUpdatedListener {

    private Button buttonBenzinAl10,buttonBenzinAl20,buttonHizmetAl,buttonSatinAldiklarim;

    private TextView textViewSonuc,textViewBenzinMiktari;

    private BillingClient mBillingClient;

    private List<SkuDetails> skuINAPPDetayListesi = new ArrayList<>();

    private List<SkuDetails> skuSUBSDetayListesi = new ArrayList<>();

    private int benzinMiktari = 10 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonBenzinAl10 = findViewById(R.id.buttonBenzinAl10);
        buttonBenzinAl20 = findViewById(R.id.buttonBenzinAl20);
        buttonHizmetAl = findViewById(R.id.buttonHizmetAl);
        buttonSatinAldiklarim = findViewById(R.id.buttonSatinAldiklarim);
        textViewSonuc = findViewById(R.id.textViewSonuc);
        textViewBenzinMiktari = findViewById(R.id.textViewBenzinMiktari);

        mBillingClient = BillingClient.newBuilder(this).enablePendingPurchases().setListener(this).build();

        mBillingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {

                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK){
                    buttonlarinDurumuDegistir(true);

                    List<String> skuListINAPP = new ArrayList<>();

                    skuListINAPP.add("benzin10");
                    skuListINAPP.add("benzin20");

                    SkuDetailsParams.Builder paramsINAPP = SkuDetailsParams.newBuilder();

                    paramsINAPP.setSkusList(skuListINAPP).setType(BillingClient.SkuType.INAPP);

                    mBillingClient.querySkuDetailsAsync(paramsINAPP.build(), new SkuDetailsResponseListener() {
                        @Override
                        public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {


                            skuINAPPDetayListesi = list;

                        }
                    });


                    List<String> skuListSUBS = new ArrayList<>();

                    skuListSUBS.add("hizmet6");

                    SkuDetailsParams.Builder paramsSUBS = SkuDetailsParams.newBuilder();

                    paramsSUBS.setSkusList(skuListSUBS).setType(BillingClient.SkuType.SUBS);

                    mBillingClient.querySkuDetailsAsync(paramsSUBS.build(), new SkuDetailsResponseListener() {
                        @Override
                        public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {


                            skuSUBSDetayListesi = list;

                        }
                    });




                }else{
                    Toast.makeText(getApplicationContext(),"Ödeme sistemi için google play hesabını kontrol ediniz",Toast.LENGTH_SHORT).show();
                    buttonlarinDurumuDegistir(false);
                }

            }

            @Override
            public void onBillingServiceDisconnected() {
                Toast.makeText(getApplicationContext(),"Ödeme sistemi şuanda geçerli değil",Toast.LENGTH_SHORT).show();
                buttonlarinDurumuDegistir(false);
            }
        });

        buttonBenzinAl10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                        .setSkuDetails(skuINAPPDetayListesi.get(0))
                        .build();

                mBillingClient.launchBillingFlow(MainActivity.this,flowParams);

            }
        });


        buttonBenzinAl20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                        .setSkuDetails(skuINAPPDetayListesi.get(1))
                        .build();

                mBillingClient.launchBillingFlow(MainActivity.this,flowParams);

            }
        });


        buttonHizmetAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                        .setSkuDetails(skuSUBSDetayListesi.get(0))
                        .build();

                mBillingClient.launchBillingFlow(MainActivity.this,flowParams);

            }
        });

        buttonSatinAldiklarim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBillingClient.queryPurchaseHistoryAsync(BillingClient.SkuType.INAPP, new PurchaseHistoryResponseListener() {
                    @Override
                    public void onPurchaseHistoryResponse(BillingResult billingResult, List<PurchaseHistoryRecord> list) {

                        if(billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null){

                            StringBuilder sb = new StringBuilder();

                            for (PurchaseHistoryRecord purchase : list){
                                sb.append(purchase.getSku()+"\n");
                            }

                            textViewSonuc.setText(sb.toString());

                        }

                    }
                });
            }
        });

    }

    private void buttonlarinDurumuDegistir(boolean durum){
        buttonBenzinAl10.setEnabled(durum);
        buttonBenzinAl20.setEnabled(durum);
        buttonHizmetAl.setEnabled(durum);
        buttonSatinAldiklarim.setEnabled(durum);
    }

    @Override
    public void onPurchasesUpdated(BillingResult billingResult, @Nullable List<Purchase> list) {

        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null){

            for ( Purchase purchase:list){

                if(!purchase.isAcknowledged()){
                    AcknowledgePurchaseParams.newBuilder()
                            .setPurchaseToken(purchase.getPurchaseToken())
                            .build();
                }

                if (purchase.getSku().equals("benzin10")){
                    benzinMiktari+=10;
                }

                if(purchase.getSku().equals("benzin20")){
                    benzinMiktari+=20;
                }

                Toast.makeText(getApplicationContext(),purchase.getSku()+ ": Ürün satın alındı.",Toast.LENGTH_SHORT).show();

                textViewBenzinMiktari.setText("Benzin : "+benzinMiktari+" Litre");

            }

        }


        if(billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED){

            Toast.makeText(getApplicationContext(),"Ödeme işlemi iptal edildi",Toast.LENGTH_SHORT).show();

        }


    }
}
